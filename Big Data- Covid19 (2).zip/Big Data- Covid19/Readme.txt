Required Packages and libraries 

1. Pandas
2. Numpy 
3. seaborn 
4. Matplotlib.pyplot or matplotlib
5. datetime ( importing datetime, timedata, date) 
6. sklearn
7. plotly 

use the following cammand to install any missing libraries or packages 

pip install [library name as mentioned above]  



Change the location according to your pc and set the location of folder Big Data- covid19 

run the following command 

python report_2_task.py 




 